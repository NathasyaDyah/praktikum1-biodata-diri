
import 'package:flutter_test/flutter_test.dart';
import 'package:biodata_diri/main.dart';

void main() {
  testWidgets('Biodata mahasiswa tampil dengan benar',
      (WidgetTester tester) async {
    await tester.pumpWidget(const BiodataApp());

    expect(find.text('Biodata Diri'), findsOneWidget);
    expect(find.text('Nathasya Dyah'), findsOneWidget);
    expect(find.text('NIM: 241080200031'), findsOneWidget);
    expect(find.text('Program studi: Informatika'), findsOneWidget);
    expect(find.text('Semester: 5'), findsOneWidget);
  });
}
